<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Prestamo>
 */
class PrestamoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
        'fecha_solicitud' => $this->faker->date,
        'fecha_prestamo' => $this->faker->date,
        'fecha_devolución' => $this->faker->date,
        'libro_id' => \App\Models\Libro::factory(),
        'usuario_id' => \App\Models\Usuario::factory(),
        ];
    }
}

