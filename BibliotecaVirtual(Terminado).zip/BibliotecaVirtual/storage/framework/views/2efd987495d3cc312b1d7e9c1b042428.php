

<?php $__env->startSection("tituloPagina", "Crear nuevo registro"); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="card">
    <h5 class="card-header">Agregar nuevo prestamo</h5>
    <div class="card-body">
      <p class="card-text">
        <form action="<?php echo e(route('prestamo.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <label for="">Fecha de solicitud</label>
          <input type="date" name="fecha_solicitud" class="form-control" required>
          <label for="">Fecha de prestamo</label>
          <input type="date" name="fecha_prestamo" class="form-control" required>
          <label for="">Fecha de devolucion</label>
          <input type="date" name="fecha_devolución" class="form-control" required>
          <label for="">Id de libro</label>
          <input type="number" name="libro_id" class="form-control" required>
          <label for="">Id de usuario</label>
          <input type="number" name="usuario_id" class="form-control" required>
            <br>
            <button class="btn btn-primary">Agregar</button>
            <a href="<?php echo e(route("prestamo.index")); ?>" class="btn btn-info">
                <span class="fas fa-undo-alt"></span> Regresar
            </a>
        </form>
      </p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TP-Proyecto\BibliotecaVirtual\resources\views/agregarprestamo.blade.php ENDPATH**/ ?>