

<?php $__env->startSection("tituloPagina", "Eliminar registro"); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="card">
    <h5 class="card-header">Eliminar persona</h5>
    <div class="card-body">
      <p class="card-text">
        <div class="alert alert-danger" role="alert">
            Estas seguro de eliminar este registro!
            <table class="table table-sm table-hover">
                <thead>
                    <th>Nombre</th>
                    <th>Correo Electronico</th>
                    <th>Telefono</th>
                    <th>Direccion</th>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($personas-> nombre); ?></td>
                        <td><?php echo e($personas-> correo_electronico); ?></td>
                        <td><?php echo e($personas-> teléfono); ?></td>
                        <td><?php echo e($personas-> dirección); ?></td>
                    </tr>
                </tbody>
            </table>
            <hr>
            <form action="<?php echo e(route("usuario.destroy", $personas->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <a href="<?php echo e(route("usuario.index")); ?>" class="btn btn-info">
                    <span class="fas fa-undo-alt"></span> Regresar
                </a>
                <button class="btn btn-danger">Eliminar</button>
            </form>
          </div>
      </p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TP-Proyecto\BibliotecaVirtual\resources\views/eliminar.blade.php ENDPATH**/ ?>