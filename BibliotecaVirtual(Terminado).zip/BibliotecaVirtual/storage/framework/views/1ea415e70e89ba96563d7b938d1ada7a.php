

<?php $__env->startSection("tituloPagina", "Actualizar registro"); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="card">
    <h5 class="card-header">Actualizar prestamo</h5>
    <div class="card-body">
      <p class="card-text">
        <form action="<?php echo e(route('prestamo.update', $personas->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field("PUT"); ?>
          <label for="">Fecha de solicitud</label>
          <input type="date" name="fecha_solicitud" class="form-control" required value="<?php echo e($personas->fecha_solicitud); ?>">
          <label for="">Fecha de prestamo</label>
          <input type="date" name="fecha_prestamo" class="form-control" required value="<?php echo e($personas->fecha_prestamo); ?>">
          <label for="">Fecha de devolucion</label>
          <input type="date" name="fecha_devolución" class="form-control" required value="<?php echo e($personas->fecha_devolución); ?>">
          <label for="">Id de libro</label>
          <input type="number" name="libro_id" class="form-control" required value="<?php echo e($personas->libro_id); ?>">
          <label for="">Id de usuario</label>
          <input type="number" name="usuario_id" class="form-control" required value="<?php echo e($personas->usuario_id); ?>">
            <br>
            <button class="btn btn-warning">Actualizar</button>
            <a href="<?php echo e(route("prestamo.index")); ?>" class="btn btn-info">
                <span class="fas fa-undo-alt"></span> Regresar
            </a>
            
        </form>
      </p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TP-Proyecto\BibliotecaVirtual\resources\views/actualizarprestamo.blade.php ENDPATH**/ ?>