

<?php $__env->startSection('tituloPagina', 'Biblioteca Virtual'); ?>
    
<?php $__env->startSection('contenido'); ?>

<div class="card">
    <h5 class="card-header">Biblioteca Virtual</h5>
    <div class="card-body">
      <div class="row">
        <div class="col-sm-12">
          <?php if($mensaje = Session::get('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e($mensaje); ?>

          </div>  
          <?php endif; ?>
          
        </div>
      </div>
      <h5 class="card-title">Listado de Prestamos</h5>
      <p>
        <a href="<?php echo e(route("prestamo.create")); ?>" class="btn btn-primary">
         <span class="fas fa-user-plus"></span> Agregar nuevo prestamo
        </a>
        <nav class="navbar bg-body-tertiary">
          <div class="container-fluid">
            <form class="d-flex" role="search" action="<?php echo e(route('prestamo.index')); ?>" method="GET">
              <input class="form-control me-2" type="text" name="busqueda" placeholder="Buscar" aria-label="Search">
              <button class="btn btn-outline-success" type="submit">Buscar</button>
              <a href="<?php echo e(route("prestamo.index")); ?>" class="btn btn-outline-warning">
                <span class="fas fa-undo-alt"></span> Restablecer
            </a>
            </form>
          </div>
        </nav>
      </p>
      <p class="card-text">
        <div class="table table-responsive">
            <table class="table table-sm table-bordered">
                <thead>
                    <th>Id</th>
                    <th>Fecha de solicitud</th>
                    <th>Fecha de prestamo</th>
                    <th>Fecha de devolucion</th>
                    <th>Nombre de libro</th>
                    <th>Nombre de usuario</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->fecha_solicitud); ?></td>
                        <td><?php echo e($item->fecha_prestamo); ?></td>
                        <td><?php echo e($item->fecha_devolución); ?></td>
                        <td><?php echo e($item->libro->título); ?></td>
                        <td><?php echo e($item->usuario->nombre); ?></td>
                        <td>
                          <form action="<?php echo e(route("prestamo.edit", $item->id)); ?>" method="GET">
                            <button class="btn btn-warning btn-sm">
                              <span class="fas fa-user-edit"></span>
                            </button>
                          </form>
                        </td>
                        <td>
                          <form action="<?php echo e(route("prestamo.show", $item->id)); ?>" method="GET">
                            <button class="btn btn-danger btn-sm">
                              <span class="fas fa-user-times"></span>
                            </button>
                          </form>
                        </td>
                    </tr>  
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>
            <hr>
            <div class="row">
              <div class="col-sm-12">
                <?php echo e($datos->appends(['busqueda'=>$busqueda])); ?>

              </div>
            </div>
        </div>
      </p>
      <a href="<?php echo e(route("inicio.index")); ?>" class="btn btn-info">
        <span class="fas fa-undo-alt"></span> Regresar
    </a>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TP-Proyecto\BibliotecaVirtual\resources\views/inicioprestamo.blade.php ENDPATH**/ ?>