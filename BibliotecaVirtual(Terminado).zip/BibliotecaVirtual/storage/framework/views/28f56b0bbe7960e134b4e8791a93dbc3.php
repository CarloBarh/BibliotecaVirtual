

<?php $__env->startSection("tituloPagina", "Eliminar registro"); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="card">
    <h5 class="card-header">Eliminar libro</h5>
    <div class="card-body">
      <p class="card-text">
        <div class="alert alert-danger" role="alert">
            Estas seguro de eliminar este registro!
            <table class="table table-sm table-hover">
                <thead>
                    <th>Titulo</th>
                    <th>Autor</th>
                    <th>Editorial</th>
                    <th>Año de Publicacion</th>
                    <th>Cantidad Disponible</th>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($personas-> título); ?></td>
                        <td><?php echo e($personas-> autor); ?></td>
                        <td><?php echo e($personas-> editorial); ?></td>
                        <td><?php echo e($personas-> año_publicación); ?></td>
                        <td><?php echo e($personas-> cantidad_disponible); ?></td>
                    </tr>
                </tbody>
            </table>
            <hr>
            <form action="<?php echo e(route("libro.destroy", $personas->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <a href="<?php echo e(route("libro.index")); ?>" class="btn btn-info">
                    <span class="fas fa-undo-alt"></span> Regresar
                </a>
                <button class="btn btn-danger">Eliminar</button>
            </form>
          </div>
      </p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TP-Proyecto\BibliotecaVirtual\resources\views/eliminarlibro.blade.php ENDPATH**/ ?>